


export async function main(event, context){
    return {
        stausCode: 200,
        body: "Hello From, Lambda!!"
    }
}

